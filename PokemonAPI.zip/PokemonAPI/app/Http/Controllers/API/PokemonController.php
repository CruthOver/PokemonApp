<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Pokemon;
use Illuminate\Http\Request;

class PokemonController extends Controller
{
    public function index() {
        $data = Pokemon::all();

        // $data = $data->map(function($item) {

        // });

        return response()->json(['success'=> true, 'message'=> "Get Pokemon Successfully", 'data'=> $data]);
    }

    public function store(Request $request)
    {
        $number = rand(1, 10);
        $index = $request->index;
        $probability = (($index / $number) / $index) * 100;

        if ($probability >= 50) {
            $pokemon = Pokemon::create($request->only(
                'name',
                'url',
                'nickname'
            ));
            if ($pokemon) {
                return response()->json(['success' => true, "message"=> "Catch Pokemon Success $number - $probability%", 'data'=> $pokemon]);
            } 
            return response()->json(['success' => false, "message"=> "Failed to Catch Pokemon", 'data'=> null], 400);
        }
        return response()->json(['success' => false, "message"=> "Failed to Catch Pokemon. Probabilty is $number - $probability%", 'data'=> null]);
    }

    public function show(Pokemon $pokemon)
    {
        //
    }

    public function update(Request $request, Pokemon $pokemon)
    {
        //
    }

    
    public function destroy(Pokemon $pokemon)
    {
        $number = rand(2, 50);
        $prima = false;
        for ($i=2; $i<=$number; $i++) {
            $index = 0;
            if ($number % $i == 0) {
                $index++;
            }

            if ($index == 2) {
                $prima = true;
            }
        }
        if ($prima) {
            $delete = Pokemon::destroy($pokemon->id);
            if ($delete) {
                return response()->json(['success'=> true, 'message'=> "Pokemon has been Release", 'data'=>null]);
            } 
        }
        return response()->json(['success'=> false, 'message'=> "Pokemon failed to release", 'data'=>null]);
    }
}
